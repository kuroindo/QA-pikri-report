
const fs = require("fs");

const report = JSON.parse(
  fs.readFileSync("newman-report.json", "utf8")
);

const executions = report.run.executions;

const notFound = executions.filter(
  (item) => item.response?.code === 404
);

const connectionErrors = executions.filter(
  (item) => item.error
);

console.log("\n===== REQUEST 404 NOT FOUND =====");

notFound.forEach((item, index) => {
  console.log(`${index + 1}. ${item.item.name}`);
  console.log(`Method: ${item.request.method}`);
  console.log(`URL: ${item.request.url}`);
  console.log(`Status: ${item.response.code}`);
  console.log("----------------------------");
});

console.log("\n===== REQUEST CONNECTION ERROR =====");

connectionErrors.forEach((item, index) => {
  console.log(`${index + 1}. ${item.item.name}`);
  console.log(`Error: ${item.error.message}`);
  console.log("----------------------------");
});

console.log("\n===== SUMMARY =====");
console.log(`Total Request: ${executions.length}`);
console.log(`404 Not Found: ${notFound.length}`);
console.log(`Connection Error: ${connectionErrors.length}`);
