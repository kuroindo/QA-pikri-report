// Pemakaian:
//   node run.js            -> semua modul
//   node run.js addon      -> hanya modul addon (smoke test)
//   node run.js addon bai  -> beberapa modul
const newman = require('newman');
const fs = require('fs');
const path = require('path');

const COLLECTION = require('./MyTech_API_Collection__Revamp__postman_collection.json');
const ONLY = process.argv.slice(2);
const OUT = path.join(__dirname, 'reports');
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });

// ---------- 1) Inject assertion ke folder Positive / Negative ----------
const BASE_TESTS = [
  "pm.test('Response diterima < 10s', () => pm.expect(pm.response.responseTime).to.be.below(10000));",
  "pm.test('Status bukan 5xx', () => pm.expect(pm.response.code).to.be.below(500));",
];
const POSITIVE = [
  ...BASE_TESTS,
  "pm.test('Status 200', () => pm.response.to.have.status(200));",
  "pm.test('Body JSON valid', () => pm.response.json());",
];
const NEGATIVE = [
  ...BASE_TESTS,
  "pm.test('Request ditolak / code != 0', () => {",
  "  if (pm.response.code >= 400) return;",
  "  const j = pm.response.json();",
  "  pm.expect(Number(j.code)).to.not.equal(0);",
  "});",
];
const inject = (items) => items.forEach((i) => {
  if (!i.item) return;
  if (i.name === 'Positive' || i.name === 'Negative') {
    i.event = [{ listen: 'test', script: { type: 'text/javascript',
      exec: i.name === 'Positive' ? POSITIVE : NEGATIVE } }];
  } else inject(i.item);
});
inject(COLLECTION.item);

// ---------- 2) Kelompokkan folder per modul (segmen pertama URL) ----------
const firstReq = (items) => {
  for (const i of items) {
    const r = i.item ? firstReq(i.item) : i.request;
    if (r) return r;
  }
};
const moduleOf = (f) => (firstReq(f.item)?.url?.path?.[0]) || 'unknown';
const groups = {};
COLLECTION.item.forEach((f) => (groups[moduleOf(f)] ||= []).push(f));

// ---------- 3) Jalankan newman per modul (berurutan) ----------
const runModule = (name, items) => new Promise((resolve) => {
  const title = `MyTech API (Revamp) - ${name}`;
  newman.run({
    collection: { ...COLLECTION, info: { ...COLLECTION.info, name: title }, item: items },
    reporters: ['cli', 'htmlextra'],
    reporter: { htmlextra: { export: path.join(OUT, `${name}.html`), title, browserTitle: title } },
    delayRequest: 100,
    timeoutRequest: 30000,
    insecure: true,
  }, (err, summary) => resolve({ name, err, summary }));
});

(async () => {
  const targets = Object.entries(groups).filter(([n]) => !ONLY.length || ONLY.includes(n));
  if (!targets.length) { console.error('Modul tidak ditemukan. Pilihan:', Object.keys(groups).join(', ')); process.exit(2); }

  const rows = [];
  for (const [name, items] of targets) {
    const { err, summary } = await runModule(name, items);
    const s = summary?.run?.stats || {};
    rows.push({
      name,
      req: s.requests?.total ?? 0, reqFail: s.requests?.failed ?? 0,
      as: s.assertions?.total ?? 0, asFail: s.assertions?.failed ?? 0,
      err: !!err,
    });
  }

  // ---------- 4) Index report ----------
  const tot = (k) => rows.reduce((a, r) => a + r[k], 0);
  const tr = rows.map((r) => `<tr class="${r.asFail || r.reqFail || r.err ? 'f' : 'p'}">
    <td><a href="${r.name}.html">${r.name}</a></td><td>${r.req}</td><td>${r.reqFail}</td>
    <td>${r.as}</td><td>${r.asFail}</td></tr>`).join('');
  fs.writeFileSync(path.join(OUT, 'index.html'), `<!doctype html><meta charset="utf-8">
<title>MyTech API Revamp - Summary</title>
<style>body{font-family:sans-serif;margin:2rem}table{border-collapse:collapse}
td,th{border:1px solid #ccc;padding:6px 12px}.f{background:#fdd}.p{background:#dfd}</style>
<h2>MyTech API Revamp - Summary ${new Date().toLocaleString('id-ID')}</h2>
<p>Total request: ${tot('req')} | Request gagal: ${tot('reqFail')} |
Assertion: ${tot('as')} | Assertion gagal: ${tot('asFail')}</p>
<table><tr><th>Modul</th><th>Request</th><th>Req gagal</th><th>Assertion</th><th>Assertion gagal</th></tr>${tr}</table>`);

  console.log('\nSelesai. Buka reports/index.html');
  process.exitCode = tot('asFail') || tot('reqFail') ? 1 : 0;
})();
